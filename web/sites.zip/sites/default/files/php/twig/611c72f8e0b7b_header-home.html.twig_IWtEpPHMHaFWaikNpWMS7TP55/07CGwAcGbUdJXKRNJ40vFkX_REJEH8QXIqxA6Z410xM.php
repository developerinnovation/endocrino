<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @ngt_theme/header-home.html.twig */
class __TwigTemplate_09d427024b483d4dc168ce7db976d39c493ef23fc94d4308a6072b30ae7d4655 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["if" => 2, "set" => 10, "for" => 13];
        $filters = ["escape" => 3];
        $functions = ["simplify_menu" => 10, "file_url" => 43];

        try {
            $this->sandbox->checkSecurity(
                ['if', 'set', 'for'],
                ['escape'],
                ['simplify_menu', 'file_url']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<header class=\"desktop\">
    ";
        // line 2
        if (($context["active_home_txt_header"] ?? null)) {
            // line 3
            echo "        <p class=\"fras description-header\"> ";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["home_txt_header"] ?? null)), "html", null, true);
            echo " </p>
    ";
        }
        // line 5
        echo "    <div class=\"box\">
        <div class=\"elements\">
            <div class=\"left\">
                <div class=\"menu\">
                ";
        // line 10
        echo "                    ";
        $context["items"] = call_user_func_array($this->env->getFunction('simplify_menu')->getCallable(), ["menu-header-general"]);
        // line 11
        echo "                    ";
        // line 12
        echo "                    <nav class=\"navigation__items\">
                        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["items"] ?? null), "menu_tree", []));
        foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
            // line 14
            echo "                            <li class=\"navigation__item\">
                                <a href=\"";
            // line 15
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "url", [])), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "text", [])), "html", null, true);
            echo "</a>
                            </li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu_item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "                    </nav>
                </div>
            </div>
            <div class=\"right\">
                <!--<div class=\"search\">
                    <form action=\"\">
                        <labe class=\"form-control input header\">
                            <img src=\"\" alt=\"\" class=\"class-ico-search\">
                            <input type=\"search\" name=\"search\" id=\"search\" placeholder=\"Buscar\">
                        </labe>
                    </form>
                </div>-->
                <div class=\"login\">
                    ";
        // line 31
        if (($context["logged_in"] ?? null)) {
            // line 32
            echo "                        <a href=\"/user/logout\" class=\"link-sign-in\">Cerrar sesión</a>
                    ";
        } else {
            // line 34
            echo "                        <a href=\"/user/login\" class=\"link-sign-in\">Iniciar sesión</a>
                        <a href=\"/register/user\" class=\"link-sign-up\">Registrarte</a>
                    ";
        }
        // line 37
        echo "                </div>
                
            </div>
        </div>
    </div>
    <figure class=\"logo-general mobile\">
        <img src=\"";
        // line 43
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), [$this->sandbox->ensureToStringAllowed(($context["logo_general_url"] ?? null))]), "html", null, true);
        echo "\">
    </figure>
</header>
";
    }

    public function getTemplateName()
    {
        return "@ngt_theme/header-home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 43,  124 => 37,  119 => 34,  115 => 32,  113 => 31,  98 => 18,  87 => 15,  84 => 14,  80 => 13,  77 => 12,  75 => 11,  72 => 10,  66 => 5,  60 => 3,  58 => 2,  55 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "@ngt_theme/header-home.html.twig", "/Volumes/HD-Project-Macbook/Web/Desarrollos Web/endocrino/web/themes/custom/ngt_theme/templates/header-home.html.twig");
    }
}
