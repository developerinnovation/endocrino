<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* themes/custom/ngt_theme/templates/user/user.html.twig */
class __TwigTemplate_9be52aaad7aa09a5251d8b039e4224d00f7a008f854ecbbc9cae8e74e6270177 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $tags = ["set" => 1, "for" => 35];
        $filters = ["escape" => 2, "raw" => 20, "striptags" => 20];
        $functions = ["drupal_field" => 2, "simplify_menu" => 32];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'for'],
                ['escape', 'raw', 'striptags'],
                ['drupal_field', 'simplify_menu']
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        ob_start(function () { return ''; });
        // line 2
        echo "    ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("field_nombre", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "
";
        $context["nombre"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 4
        echo "
";
        // line 5
        ob_start(function () { return ''; });
        // line 6
        echo "    ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("field_apellidos", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "
";
        $context["apellidos"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
<article";
        // line 9
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["attributes"] ?? null)), "html", null, true);
        echo " data-ilar=\"\">
  <div class=\"izq menu-live\">
    
    <div class=\"top\">
      <div class=\"picture\">
        <figure>  
          ";
        // line 15
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("user_picture", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "
        </figure>
      </div>
      <div class=\"info\">
        <div class=\"text\">
            <h3 class=\"title\">";
        // line 20
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(strip_tags($this->sandbox->ensureToStringAllowed(($context["nombre"] ?? null))));
        echo " ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(strip_tags($this->sandbox->ensureToStringAllowed(($context["apellidos"] ?? null))));
        echo "</h3>
            <div class=\"member_for\">
              ";
        // line 22
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "member_for", [])), "html", null, true);
        echo "
            </div>
        </div>
      </div>
    </div>


    <div class=\"menu\">
      <div>
        ";
        // line 32
        echo "        ";
        $context["items"] = call_user_func_array($this->env->getFunction('simplify_menu')->getCallable(), ["menu-perfil-usuario"]);
        // line 33
        echo "        ";
        // line 34
        echo "        <nav class=\"navigation__items\">
            ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["items"] ?? null), "menu_tree", []));
        foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
            // line 36
            echo "              <li class=\"navigation__item\">
                <a href=\"";
            // line 37
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "url", [])), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "text", [])), "html", null, true);
            echo " <i class=\"row\"></i></a>
              </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu_item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "        </nav>
      </div>
    </div>


    <div class=\"menu-informative\">
      <div>
        ";
        // line 48
        echo "        ";
        $context["items"] = call_user_func_array($this->env->getFunction('simplify_menu')->getCallable(), ["menu-informativo"]);
        // line 49
        echo "        ";
        // line 50
        echo "        <nav class=\"navigation__items\">
          ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["items"] ?? null), "menu_tree", []));
        foreach ($context['_seq'] as $context["_key"] => $context["menu_item"]) {
            // line 52
            echo "            <li class=\"navigation__item\">
              <a href=\"";
            // line 53
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "url", [])), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($context["menu_item"], "text", [])), "html", null, true);
            echo "</a>
            </li>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['menu_item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "        </nav>
      </div>
    </div>

    <div class=\"buttom\">
      <div>
        <a href=\"/user/logout\">Cerrar sesión</a>
      </div>
    </div>

  </div>


  <div class=\"der\">

    <div class=\"left\">
      <div class=\"picture\">
        <figure>  
          ";
        // line 74
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("user_picture", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "
        </figure>
      </div>
      <div class=\"text\">
          <h3 class=\"title\">";
        // line 78
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(strip_tags($this->sandbox->ensureToStringAllowed(($context["nombre"] ?? null))));
        echo " ";
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(strip_tags($this->sandbox->ensureToStringAllowed(($context["apellidos"] ?? null))));
        echo "</h3>
      </div>
      <div class=\"member_for\">
              ";
        // line 81
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["content"] ?? null), "member_for", [])), "html", null, true);
        echo "
      </div>
      <div class=\"location\">       
          <h3><i class=\"location\">ubicacion</i>";
        // line 84
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("field_ubicacion_geografica", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "</h3>  
      </div>
      <div class=\"action\">
        <a href=\"/user/edit\" class=\"edit-user\">Editar mis datos</a>
      </div>
    </div>


    <div class=\"rigth\">
      <div class=\"name\">
        <span>Nombre de usuario y correo electrónico</span>
        <h3>";
        // line 95
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed($this->getAttribute($this->getAttribute(($context["user"] ?? null), "mail", []), "value", [])), "html", null, true);
        echo "</h3>
      </div>

      <div class=\"name\">
        <span>Fecha de nacimiento</span>
        <h3>";
        // line 100
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("field_fecha_nacimiento", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "</h3>  
      </div>

      <div class=\"name\">
        <span>Profesión</span>
        <h3>";
        // line 105
        echo $this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\twig_tweak\TwigExtension')->drupalField("field_profesion", "user", $this->sandbox->ensureToStringAllowed($this->getAttribute(($context["user"] ?? null), "id", []))), "html", null, true);
        echo "</h3>
      </div>

    </div>



  </div>


</article>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/ngt_theme/templates/user/user.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  245 => 105,  237 => 100,  229 => 95,  215 => 84,  209 => 81,  201 => 78,  194 => 74,  174 => 56,  163 => 53,  160 => 52,  156 => 51,  153 => 50,  151 => 49,  148 => 48,  139 => 40,  128 => 37,  125 => 36,  121 => 35,  118 => 34,  116 => 33,  113 => 32,  101 => 22,  94 => 20,  86 => 15,  77 => 9,  74 => 8,  68 => 6,  66 => 5,  63 => 4,  57 => 2,  55 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "themes/custom/ngt_theme/templates/user/user.html.twig", "/Volumes/HD-Project-Macbook/Web/Desarrollos Web/endocrino/web/themes/custom/ngt_theme/templates/user/user.html.twig");
    }
}
